==============================================================
TORTOISE v1.0.3 FREE
by YAFT Designs
Auto-dimensioned A3 sheet layouts for glass and panels in Rhino 8
==============================================================
Author : YAFT Designs
Contact: yaftdesigns@gmail.com

LICENCE
Free for 60 days from first use, for personal and commercial work. After 60 days Tortoise keeps working but
marks every sheet, PDF, DWG/DXF and BOM with TRIAL EXPIRED until you enter a licence key.
Buy a licence at https://yaftdesigns.com/tortoise, then paste the key in Tortoise > About / Help > Licence.
The key is checked online (needs internet now and then). Provided as is, with no warranty.
Please do not resell or repackage it. Always keep a copy of your model before running.

WHAT IT DOES
Select your flat glass or panel surfaces. Tortoise makes one A3 layout per panel with
automatic dimensions and side letters (A, B, C... clockwise from the top-left corner),
fills a title block, and exports:
  - DWG or DXF for each panel
  - PDFs: one per panel and/or one combined binder PDF in sheet order
  - an Excel BOM (bill of materials) with spec, glass type, sizes, areas and quantities

CONTENTS OF THIS PACKAGE
  Tortoise.rhp                 the plugin
  Tortoise.deps.json           support file (keep next to the .rhp)
  Tortoise.runtimeconfig.json  support file (keep next to the .rhp)
  README.txt                   this guide
  Feedback_Form.txt            please fill this in and email it back

REQUIREMENTS
  - Rhino 8 for Windows
  - Excel is not needed to create the BOM, only to open it
  - Mac is not supported in v1.0.3


==============================================================
PART 1: INSTALL
==============================================================
Step 1  UNBLOCK THE ZIP (important)
        Windows blocks plugins that came from the internet or email.
        Right-click Tortoise_v1.0.3_Free.zip > Properties > at the bottom tick "Unblock" > OK.
        If you skip this, Rhino may refuse to load the plugin.

Step 2  UNZIP
        Extract to a folder you will keep, for example
        C:\Tools\Tortoise\
        Do not run it from inside the zip, and do not delete the folder later
        (Rhino loads the plugin from there).
        Keep Tortoise.rhp together with its two .json files.

Step 3  INSTALL IN RHINO
        Open Rhino 8. Either:
          a) Tools > Options > Plug-ins > Install... > pick Tortoise.rhp > Open
          b) or drag Tortoise.rhp from Explorer into the Rhino window

Step 4  RESTART RHINO
        Close Rhino fully and open it again.

Step 5  CHECK
        Type  Tortoise  on the command line and press Enter.
        A window titled "Tortoise v1.0.3" opens with four tabs:
        Panel Export | Templates | Dimensions | Keys.

TO UPDATE LATER
        Close Rhino, replace the old files with the new ones (same folder), open Rhino.

TO REMOVE
        Tools > Options > Plug-ins > select Tortoise > Remove. Then delete the folder.

IF IT DOES NOT LOAD
  - Repeat Step 1 (Unblock) on the zip, and unzip again.
  - Make sure you are on Rhino 8 (Help > About Rhino).
  - Make sure the .rhp and both .json files are in the same folder.
  - Email us the text shown on the Rhino command line after you try to install.


==============================================================
PART 2: PREPARE YOUR MODEL
==============================================================
Tortoise works on single flat surfaces (planar surfaces, one surface per panel).

1. Put each panel surface in your model (any position, any rotation, 2D or 3D).
2. Give every panel a user text key called  ID
   - Select the surface > Properties panel > Attribute User Text > add
     Key: ID     Value: the panel number, for example G-101
   - Each panel needs its own ID. Tortoise uses the ID in the layout name,
     the drawing number, the PDF file name and the BOM.
3. Optional key  SPEC  with value  DGU, TGU or SGU:
     DGU = Double Glass Unit
     TGU = Triple Glass Unit
     SGU = Spandrel Glass Unit
   If SPEC is missing the panel is treated as DGU. You can change it later in the review list.
4. Save your file first.

Tip: if you do not have a model handy, draw a few rectangles, parallelograms and
trapezoids with the Plane command and add ID text to each.


==============================================================
PART 3: WALKTHROUGH
==============================================================
Type  Tortoise  to open the window. It stays linked to your file, and settings
are saved inside the .3dm.

----- STEP A: SET UP THE TEMPLATE (Templates tab, once per project) -----
1. Click the Templates tab.
2. Click "Make fab A3 template". This builds an A3 sheet (called Fab_A3) with border,
   title block, tolerance row, revision block and logo.
   (If one already exists you are asked: Yes = rebuild it, No = only refresh the logo.)
3. Logo: this free edition has no built-in logos. Pick your own PNG/JPG with Choose PNG...
   (it is fitted into the logo cell). Until you pick one the logo cell stays empty.
4. Material: choose Glass, Aluminium or Others (type the name if Others).
   Each material keeps its own spec text and tolerances.
5. Fill the title block fields:
   - Project group: Job no., Project, Drawing title, Drawing no., Drawn by, Date
     (leave Date blank to use today's date)
   - Material group: spec lines, grade, thickness (mm) and density (kg/m3) used for weight,
     finishes, and the Post paint / Pre paint / Part / Sub assem. tick boxes
   - Tolerances group: Cutting, Accuracy and Fabrication tolerances
   - Assembly group: "Assemble on part" lines
   Drawing no. tip: put %ID% for the glass ID and %SEQ% for the sheet number,
   for example  %ID%-%SEQ%
6. Click "Apply to template + all sheets". The fields fill the template and any layouts
   already made.
   (The template is a normal Rhino layout. You can open it and edit lines or text.
   Any text written as %TOKEN% is replaced automatically on every sheet.)

----- STEP B: GLASS TYPES (Panel Export tab, step 1) -----
1. Click the Panel Export tab. Step 1 is Material (same as the Templates tab).
2. For Glass, the "Glass types in this project" box lists your types:
   Name | Spec (DGU / TGU / SGU) | Thickness (mm), for example 6+12+6
3. Press "+" to add another type, "-" to remove one. The first type is DGU by default.
   These types appear in the dropdown of the review list.

----- STEP C: PICK THE PANELS AND RUN -----
1. Step 2, Panels: click "Select panel srfs", select your surfaces in Rhino and press Enter.
   The window shows how many panels were selected.
2. Step 3, Template: leave Fab_A3 (or choose another template layout).
3. Step 4, Scale: Auto fits each panel to the sheet. Or type a Manual scale (1 : n).
4. Click "Run (create layouts + auto dims)".
   One layout is created per panel, named GS_<ID>, with dimensions, side letters A, B, C...
   and the title block filled in. Identical panels are counted together for quantity.

----- STEP D: REVIEW AND REORDER (step 5) -----
The Review list shows every sheet: Sht number | ID | Size | Glass type | Layout | Status.
  - REORDER: hold the three-line handle (the symbol at the left of a row) and drag the row
    up or down. A blue line shows where it will drop. Let go to drop it.
    You can also select a row and use the Up / Down buttons.
    Sheet numbers (SHT 2/18) and the layout tab order update straight away.
    The drawing number follows the order only if your Drawing no. field has %SEQ%.
  - GLASS TYPE: click the type cell of a row and choose a type from the dropdown.
    This changes the Spec shown on the sheet and in the BOM.
  - RENAME: double-click a layout name to rename that layout.
  - PREVIEW: the right side shows the selected sheet.
  - "Go to selected layout (close dialog)" jumps to that layout in Rhino.

----- STEP E: REVISIONS (Templates tab) -----
1. Templates tab > Revision (drawing releases).
2. Type the amendment text (for example ISSUED FOR PRODUCTION) and who made it.
3. Click "Issue release". The next letter (A, B, C...) is added to the revision block
   on every sheet, with the date. The latest 5 releases show on the sheet.
4. "Remove last" deletes the latest release.

----- STEP F: OUTPUT (step 6) -----
1. Output folder: type a path or press Browse.
2. EXPORT DWG / DXF: choose DWG or DXF in the dropdown and press "Export each panel".
   The tick box "DWG/DXF: include full layout sheet" off = panel and dimensions only,
   on = full sheet with border and title block.
3. PDF: press "Batch plot to PDF".
   - "One PDF per panel": one PDF file per sheet in a PDF subfolder
   - "Also one binder PDF (sheet order)": one combined PDF, pages in the order of the review list
   A message shows the folder and the binder file name when done.
4. BOM: press "Export BOM (Excel)". The Excel file (in a BOM subfolder) has:
   - a summary sheet: item, shape, length, width, spec, glass type, thickness, sides A, B, C...,
     area each, quantity, total area and the panel IDs in each item
   - a glass list sheet with one row per panel
   Panels with a different type, spec or thickness are listed as separate items.

----- KEYS TAB -----
Lists the panel keys (ID, SPEC, QTY, WEIGHT) and the template tokens with examples.
The key names for panel ID, part qty and part weight can be changed per file.
Part qty and part weight on the sheet stay blank until the panel has that attribute.
The BOM quantity also stays blank until a QTY attribute is given.

----- CURVED PANELS -----
Panels with arcs or curved edges are supported. Each straight edge gets a length dimension,
each arc gets an arc length (with the arc symbol), a radius note (R1, R2...) and a marked
centre. Edge letters A, B, C... follow the outline and the lengths fill the DIM A-I cells.
The BOM adds R1, R2... columns and a "Radius on side" column.

----- DIMENSIONS TAB -----
Controls the dimension style used on the sheets (text size, arrows and similar settings).
Change it, then apply to update the dimensions.


==============================================================
TIPS AND NOTES
==============================================================
- The window stays open between actions. Changes are saved in the file, so reopening
  Tortoise later brings back your template, glass types, order and revisions.
- If you add or change panels, press Run again. Existing layouts are reused.
- Check the review list before exporting. Order, glass type and layout names are used
  by the PDFs, the binder and the BOM.
- Weight on the sheet uses the thickness and density you entered in the Templates tab.
- Save your .3dm before large runs.


==============================================================
KNOWN LIMITS (v1.0.3)
==============================================================
- DWG export writes dimension text as fixed text. For fully live dimensions export DXF
  and use Save As DWG in AutoCAD.
- Templates made in older test versions need "Make fab A3 template" again (answer Yes).
- Flat panels only (curved outlines are fine, curved surfaces are not). Sheet-metal flats are planned.
- Curved outlines have no corner angles. Very shallow arcs show a large radius marked "(center off sheet)".
- Holes and cutouts are not drawn or dimensioned yet.
- Windows only.
- Please keep a copy of your model before running on important files.


==============================================================
FEEDBACK
==============================================================
Report bugs and requests by filling in Feedback_Form.txt and emailing it to  yaftdesigns@gmail.com
with a screenshot and, if possible, a small .3dm with a few sample panels.
Please mention the version number shown in the Tortoise window title.

(c) 2026 YAFT Designs.
